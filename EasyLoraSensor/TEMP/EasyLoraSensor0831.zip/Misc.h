#ifndef MISC_H
#define MISC_H
void LoadSettings(void);
void hardwareInit();
void LoadTaskSettings(byte TaskIndex);
byte getDeviceIndex(byte Number);
#endif
